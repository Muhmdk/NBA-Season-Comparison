import React, { Component } from 'react';
import axios from 'axios';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      playerName: null,
      playerName2: null,
      playerStats: {},
      playerStats2: {},
    };
  }

  handleSubmit = (e) => {
    e.preventDefault();
    this.getPlayerStats(this.state.playerName, 'playerStats');
    this.getPlayerStats(this.state.playerName2, 'playerStats2');
  };

  handleChange = (event, player) => {
    const replace = event.target.value.split(' ').join('_');
    if (replace.length > 0) {
      this.setState({ [player]: replace });
    } else {
      alert('Please type player name!');
    }
  };

  getPlayerStats = (playerName, playerStatsKey) => {
    axios
      .get(`https://www.balldontlie.io/api/v1/players?search=${playerName}`)
      .then(async (res) => {
        if (res.data.data[0] === undefined) {
          alert("This player is either injured or hasn't played yet!");
        } else if (res.data.data.length > 1) {
          alert('Please specify the name more!');
        } else {
          const playerId = res.data.data[0].id;
          await axios
            .get(
              `https://www.balldontlie.io/api/v1/season_averages?season=2022&player_ids[]=${playerId}`
            )
            .then(async (res) => {
              console.log(res.data.data);
              this.setState({ [playerStatsKey]: res.data.data[0] });
            })
            .catch((err) => {
              console.log(err);
            });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  render() {
    return (
      <div className='App'>
        
        <h2>Who is having a better season?</h2>
        <form onSubmit={this.handleSubmit}>
          <label>
            Player 1:
            <input
              type='text'
              value={this.state.playerName}
              onChange={(event) =>
                this.handleChange(event, 'playerName')
              }
              placeholder='Please enter player name'
            />
          </label>
          <label>
            Player 2:
            <input
              type='text'
              value={this.state.playerName2}
              onChange={(event) =>
                this.handleChange(event, 'playerName2')
              }
              placeholder='Please enter player name'
            />
          </label>
          <input type='submit' value='Submit' />
        </form>
        <div>
          <h2>Player 1 Stats:</h2>
          Games played: {this.state.playerStats['games_played']} 
          <br />
          Minutes averaged: {this.state.playerStats['min']} mpg
          <br />
          Points averaged: {this.state.playerStats['pts']} ppg
          <br />
          Rebounds averaged: {this.state.playerStats['reb']} rpg
          <br />
          Assists averaged: {this.state.playerStats['ast']} apg
          <br />
          Steals averaged: {this.state.playerStats['stl']} spg
          <br />
          Blocks averaged: {this.state.playerStats['blk']} bpg
          <br />
          Turnovers averaged: {this.state.playerStats['turnover']} tpg
        </div>
        <div>
          <h2>Player 2 Stats:</h2>
          Games played: {this.state.playerStats2['games_played']}
          <br />
          Minutes averaged: {this.state.playerStats2['min']} mpg
          <br />
          Points averaged: {this.state.playerStats2['pts']} ppg
          <br />
          Rebounds averaged: {this.state.playerStats2['reb']} rpg
          <br />
          Assists averaged: {this.state.playerStats2['ast']} apg
          <br />
          Steals averaged: {this.state.playerStats2['stl']} spg
          <br />
          Blocks averaged: {this.state.playerStats2['blk']} bpg
          <br />
          Turnovers averaged: {this.state.playerStats2['turnover']} tpg
        </div>
      </div>
    );
  }
}

export default App;